a= "South East Asia"
b= "Asia South Pacific and South Asia Pacific"
c= "Middle East"
d= "Europe"
e="North America"
f="Australia"
g="Africa"
#constant for regions