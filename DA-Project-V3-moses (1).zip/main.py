#import pandas for data analysis
import pandas as pd
import constant
#import matplotlib.pyplot as plt for displaying data
import matplotlib.pyplot as plt
#import counter from collection
from collections import Counter 
class DataAnalysis():
  def __init__(self):
    Display_Visitors()
#Function to Calculate the total visitor for each country and Displaying it in Pie Chart and Data Frame
def Display_Visitors():
  df = pd.read_csv('MonthyVisitors.csv')
  region_list = ["1", "2", "3", "4", "5", "6", "7"] 
  region_name = ""
  visitor = []
  countries = []
  total_visitor = []
  visitor_dict = {}
  #Check for the right input from the user
  while True:
    x =  input("input Start date YYYYMMM eg.(1998May) Min:1978Jan:")
    #if error continue prompt for input
    if not x in date_list:
      print('Error!')
    #if no error break out of loop
    elif x in date_list:
      break
  #Check for the right input
  while True:
    y= input("input End date YYYYMMM eg.(2008May) Max:2017Nov :")
    #if error continue prompt for input
    if not y in date_list:
      print("Error!")
    #if no error break out of loop
    elif y in date_list:
      break
  #assign variable a and b value according to input
  a = date_dict[x]
  a = int(a)
  b = date_dict[y]
  b = int(b)
  b =  b+1
  #Print guide for user
  print("Select a region:", "\n", "(1)South East Asia(SEA)", "\n", "(2)Asia South Pacific and South Asia Pacific(ASP and SAP)","\n", "(3)Middle East(ME)", "\n", "(4)Europe(EU)", "\n","(5)North America(NA)", "\n", "(6)Australia(AU)", "\n", "(7)Africa(AF)")
  while True:
        #prompt for user input
        region = input("Enter a region. Enter 1 for SEA or 2 for ASP etc: ")
        region = str(region)
        # if user input not in region_list , print error
        if not region in region_list:
            print("Error!")
        #else if region in region_list , break out of loop
        elif region in region_list:
            break
  #Match input with region and assign number to variable c and d
  if region == "1":
        c = 2#index for Brunei
        c = int(c)
        d = 9#index for Myanmar
        d = int(d)
        region_name = constant.a#index South-East Asia = 2:9
  elif region == "2":
        c = 9#index for Japan
        c = int(c)
        d = 17#index for Sri Lanka
        d = int(d)
        region_name = constant.b#index Asia South Pacific and South Asia Pacific = 9:17
  elif region == "3":
        c = 17#index for Saudi Arabia
        c = int(c)
        d = 20#index for UAE
        d = int(d)
        region_name = constant.c#index Middle East = 17:20
  elif region == "4":
        c = 20#index for United Kingdom
        c = int(c)
        d = 31#index for Cis and Eastern Europe
        d = int(d)
        region_name = constant.d#index Europe = 20:31
  elif region == "5":
        c = 31#index for USA
        c = int(c)
        d = 33#Australia
        d = int(d)
        region_name = constant.e#index North America = 31:33
  elif region == "6":
        c = 33#index for Australia
        c = int(c)
        d = 35#index for New Zealand
        d = int(d)
        region_name = constant.f#index Australia = 33:35
  elif region == "7":
        c = 35#index for Africa
        c = int(c)
        d = 36#index for last box
        d = int(d)
        region_name = constant.g#index Africa = 35:36
  #Show user region and time period chosen by them
  print(region_name, "was selected for region and","and time period between",x,"to",y,".")

  
  #specifying the dataframe
  #df.iloc[input start date:input end date,first country of input region:last country of input region]
  df = df.iloc[a:b, c:d]


  #index d - index c to find how many countries in region
  #country_idx= int(last index country) - int(first index country)
  country_idx = d - c
  #for loop to append every country in the column
  #specify the columns from given region and appending every country into a list
  #repeat the proccess (amount of countries in region) amount of times
  for country in df.columns[0:int(country_idx)]:
      countries.append(country)
      #append every visitor by columns
      for visitors in df[country]:
          visitor.append(visitors)
  #converting element in visitor list from string to integer for addition purposes, if element =="na" convert to 0
  for i in range(0, len(visitor)):
      if visitor[i] == " na ":
          visitor[i] = 0
      else:
          visitor[i] = int(visitor[i])
  
  #find out how many number in the list
  number_of_visitors = len(visitor)
  #counter = how many number a country have
  counter = number_of_visitors / len(countries)
  #Initialize Variables for index of the list
  Index1 = 0
  Index2 = int(counter)
  #summing the total for each country and appending it to total_visitor list
  #repeat the process (amount of countries in region) amount of times
  for i in range(0, (len(countries))):
      total_visitor.append(sum(visitor[Index1:Index2]))
      Index1 = Index1 + (int(counter))
      Index2 = Index2 + (int(counter))
  
  #create dict according countries(key):total_visitor(value)
  visitor_dict = {countries[i]: total_visitor[i]for i in range(len(countries))}
  #sort dictionary in descending order
  sort_visitor_dict = sorted(visitor_dict.items(),key=lambda x: x[1],reverse=True)
  #convert list to dictionary
  visitor_dict = dict(sort_visitor_dict)
  #find the top 3 country with the most visitors
  k = Counter(visitor_dict) 
  high = k.most_common(3)
  #convert list to datatframe
  df = pd.DataFrame(high , columns=["Country", "Visitors"])
  #print the data table in descending order
  print(df)
  #Initialize lists
  labels = []
  sizes = []
  #appending the list with values from the data frame
  for x in df['Country']:
    labels.append(x)
  for y in df["Visitors"]:
    sizes.append(y)
  #initialize list and variable
  distance = 0.1
  seperate = []
  #for loop to append distance according to amount of region in countries
  for i in range(0, len(df['Country'])):
    seperate.append(distance)
  # Plot pie chart 
  plt.pie(sizes,labels=labels, explode=seperate, startangle=90, autopct='%1.2f%%',shadow=True)
  plt.axis('equal')
  #create legend
  plt.legend(loc="best")
  #Show pie chart
  plt.show()
#Main Function Branch
if __name__ == '__main__':

    #Project Title
    print('######################################')
    print('# Data Analysis App - PYTHON Project #')
    print('######################################')
    #initialize list and variables
    df = pd.read_csv('MonthyVisitors.csv')
    year_list = []
    month_list = []
    date_dict = {}
    #appending every year in The "Year" column
    for year in df["Year"]:
      year_list.append(year)
    #removing NaN from the list
    year_list = [x for x in year_list if str(x) != 'nan']
    #removing the decimal point from the int
    year_list = list(map(int,year_list))
    #change the int to str
    year_list = list(map(str,year_list))
    #appending every month in The "Month" column
    for month in df["Month"]:
      month_list.append(month)
    #removing NaN from the list
    month_list = [x for x in month_list if str(x) != 'nan']
    # using list comprehension + zip() 
    # interlist element concatenation 
    date_list = [i + j for i, j in zip(year_list, month_list)] 
    #initialize list and variables for date_list
    index_list = []
    index_number = 0
    #appending index numbers to the length of date list
    for i in range(0,len(date_list)):
      index_list.append(index_number)
      index_number=index_number+1
    #Dictionary with date_list[i] as Key and index_list[i]  as Value
    date_dict  = { date_list[i]: index_list[i]for i in range(len(date_list))}
    #perform data analysis on specific excel (CSV) file
    DataAnalysis()
  